import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'auth_service.dart';
import 'constants.dart';
import 'env_keys.dart';
import 'google_drive_service.dart';
import 'widgets.dart';

/// Study Materials — §1 (Faculty uploads syllabus/material), §2 (Students
/// share their own materials/event brochures), §3 (download locally or
/// "Save to Drive"). Everyone reads/writes the SAME shared Drive folder
/// (see EnvKeys.studyMaterialsFolderId) — there's no separate app
/// database for this feature, Drive itself is the shared source of
/// truth, so uploads from any user show up for everyone immediately.
class StudyMaterialsScreen extends StatefulWidget {
  const StudyMaterialsScreen({super.key});

  @override
  State<StudyMaterialsScreen> createState() => _StudyMaterialsScreenState();
}

class _StudyMaterialsScreenState extends State<StudyMaterialsScreen> {
  final _drive = GoogleDriveService();
  bool _loading = true;
  bool _uploading = false;
  String? _error;
  List<DriveFileInfo> _files = [];
  Timer? _autoRefresh;

  @override
  void initState() {
    super.initState();
    _loadFiles();
    // Drive is the shared source of truth and there's no push-notification
    // backend, so a light background poll is what makes an upload from
    // one device "instantly" show up on another that already has this
    // screen open — pull-to-refresh still covers the rest.
    _autoRefresh = Timer.periodic(
        const Duration(seconds: 15), (_) => _loadFiles(silent: true));
  }

  @override
  void dispose() {
    _autoRefresh?.cancel();
    super.dispose();
  }

  bool get _isFaculty =>
      context.read<AuthService>().currentUser?.role == UserRole.faculty;

  Future<void> _loadFiles({bool silent = false}) async {
    if (!silent) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      if (EnvKeys.studyMaterialsFolderId ==
          'PASTE_YOUR_SHARED_FOLDER_ID_HERE') {
        throw Exception(
            'No shared folder configured yet — set EnvKeys.studyMaterialsFolderId first.');
      }
      final signedIn = await _drive.signIn(interactive: !silent);
      if (!signedIn) throw Exception('Google sign-in was cancelled or failed.');
      var files =
          await _drive.listFilesInFolder(EnvKeys.studyMaterialsFolderId);
      // File Share Options enforcement: students never see "Faculty
      // only" materials, no matter how they got the folder link.
      if (!_isFaculty) {
        files = files
            .where((f) => f.visibility != MaterialVisibility.facultyOnly)
            .toList();
      }
      if (!mounted) return;
      setState(() {
        _files = files;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      // A silent background refresh failing (e.g. brief network blip)
      // shouldn't blow away a perfectly good list already on screen.
      if (silent) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _upload() async {
    // Defensive checks — the FAB can still be tapped even while the list
    // above is showing a config/sign-in error, so re-verify both here
    // instead of assuming _loadFiles() already succeeded.
    if (EnvKeys.studyMaterialsFolderId == 'PASTE_YOUR_SHARED_FOLDER_ID_HERE') {
      _toast(
          'No shared folder configured yet — set EnvKeys.studyMaterialsFolderId first.');
      return;
    }
    if (!_drive.isSignedIn) {
      final signedIn = await _drive.signIn();
      if (!signedIn) {
        if (mounted) _toast('Google sign-in was cancelled or failed.');
        return;
      }
    }

    final picked = await FilePicker.pickFiles();
    if (picked.isEmpty || picked.single.path == null) return;

    if (!mounted) return;
    final details = await _showUploadDetailsDialog(picked.single.name);
    if (details == null) return; // cancelled

    setState(() => _uploading = true);
    try {
      await _drive.uploadFile(
        folderId: EnvKeys.studyMaterialsFolderId,
        localFile: File(picked.single.path!),
        fileName: details.fileName,
        mimeType: _guessMimeType(
          details.fileName.contains('.')
              ? details.fileName.split('.').last
              : null,
        ),
        visibility: details.visibility,
      );
      if (!mounted) return;
      _toast('Uploaded "${details.fileName}".');
      await _loadFiles();
    } catch (e) {
      if (!mounted) return;
      _toast('Upload failed: $e');
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  /// Faculty Screen step 1: a form asking for File Name + File Share
  /// Options before the upload is actually sent. Students get the same
  /// form but can only ever share to "Everyone" — only faculty can
  /// restrict a file to "Faculty only".
  Future<_UploadDetails?> _showUploadDetailsDialog(String pickedName) {
    final nameController = TextEditingController(text: pickedName);
    var visibility = MaterialVisibility.everyone;
    final isFaculty = _isFaculty;

    return showDialog<_UploadDetails>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Upload Study Material'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'File Name',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              const Text('File Share Options',
                  style: TextStyle(fontWeight: FontWeight.w600)),
              RadioListTile<MaterialVisibility>(
                contentPadding: EdgeInsets.zero,
                dense: true,
                value: MaterialVisibility.everyone,
                groupValue: visibility,
                title: const Text('Everyone (Students & Faculty)'),
                onChanged: (v) => setDialogState(() => visibility = v!),
              ),
              RadioListTile<MaterialVisibility>(
                contentPadding: EdgeInsets.zero,
                dense: true,
                value: MaterialVisibility.facultyOnly,
                groupValue: visibility,
                title: const Text('Faculty only'),
                onChanged: isFaculty
                    ? (v) => setDialogState(() => visibility = v!)
                    : null,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final name = nameController.text.trim();
                if (name.isEmpty) return;
                Navigator.pop(ctx,
                    _UploadDetails(fileName: name, visibility: visibility));
              },
              child: const Text('Upload'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openInBrowser(DriveFileInfo file) async {
    final uri = Uri.parse(file.webViewLink);
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) _toast('Could not open this file.');
  }

  Future<void> _downloadLocally(DriveFileInfo file) async {
    _toast('Downloading "${file.name}"...');
    try {
      // Saves into the app's own documents folder — no storage permission
      // needed, works the same on every Android version. This is a
      // private, app-specific location (not the public Downloads
      // folder you'd browse in a file manager); "Open" above is the
      // quicker option for just viewing a file, this is for an offline
      // copy the app itself can keep re-using.
      final dir = await getApplicationDocumentsDirectory();
      final savePath = '${dir.path}/${file.name}';
      await _drive.downloadFile(fileId: file.id, savePath: savePath);
      if (!mounted) return;
      _toast('Saved to app storage: $savePath');
    } catch (e) {
      if (!mounted) return;
      _toast('Download failed: $e');
    }
  }

  Future<void> _saveToMyDrive(DriveFileInfo file) async {
    _toast('Saving "${file.name}" to your Google Drive...');
    try {
      await _drive.copyToMyDrive(fileId: file.id, fileName: file.name);
      if (!mounted) return;
      _toast('Saved to your Drive (My Drive > ${file.name}).');
    } catch (e) {
      if (!mounted) return;
      _toast('Save to Drive failed: $e');
    }
  }

  String _guessMimeType(String? extension) {
    switch (extension?.toLowerCase()) {
      case 'pdf':
        return 'application/pdf';
      case 'doc':
        return 'application/msword';
      case 'docx':
        return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      case 'ppt':
        return 'application/vnd.ms-powerpoint';
      case 'pptx':
        return 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
      case 'jpg':
      case 'jpeg':
        return 'image/jpeg';
      case 'png':
        return 'image/png';
      default:
        return 'application/octet-stream';
    }
  }

  void _toast(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Study Materials')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: (_uploading || _loading) ? null : _upload,
        icon: _uploading
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Colors.white))
            : const Icon(Icons.upload_file),
        label: Text(_uploading ? 'Uploading...' : 'Upload'),
      ),
      body: RefreshIndicator(
        onRefresh: () => _loadFiles(),
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return ListView(
        padding: const EdgeInsets.all(kPad),
        children: [
          const SizedBox(height: 60),
          Icon(Icons.cloud_off, size: 48, color: AppColors.textSecondary),
          const SizedBox(height: 12),
          Text(_error!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.textSecondary)),
          const SizedBox(height: 16),
          Center(
              child: ElevatedButton(
                  onPressed: () => _loadFiles(), child: const Text('Retry'))),
        ],
      );
    }
    if (_files.isEmpty) {
      return const EmptyState(
        message:
            'No materials shared yet. Tap "Upload" to add a syllabus, notes, or an event brochure.',
        icon: Icons.folder_open_outlined,
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(kPad, kPad, kPad, 90),
      itemCount: _files.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) {
        final f = _files[i];
        return Card(
          child: ListTile(
            leading: Icon(_iconFor(f.mimeType), color: AppColors.primary),
            title: Text(f.name, maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Wrap(
              spacing: 6,
              runSpacing: 2,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                Text(
                  [
                    if (f.uploaderName != null) f.uploaderName,
                    if (f.sizeBytes != null) _formatSize(f.sizeBytes!),
                    if (f.createdOn != null)
                      f.createdOn!.toLocal().toString().split(' ').first,
                  ].whereType<String>().join(' • '),
                ),
                // Only faculty ever see this chip — students never get a
                // "Faculty only" file in their list to begin with.
                if (f.visibility == MaterialVisibility.facultyOnly)
                  const Chip(
                    label: Text('Faculty only', style: TextStyle(fontSize: 11)),
                    visualDensity: VisualDensity.compact,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    padding: EdgeInsets.zero,
                  ),
              ],
            ),
            onTap: () => _openInBrowser(f),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // A clear, one-tap download button — not buried in a
                // menu — so students always have an obvious way to save
                // the file to their device.
                IconButton(
                  icon: const Icon(Icons.download_outlined),
                  tooltip: 'Download to device',
                  onPressed: () => _downloadLocally(f),
                ),
                PopupMenuButton<String>(
                  onSelected: (action) {
                    switch (action) {
                      case 'open':
                        _openInBrowser(f);
                        break;
                      case 'drive':
                        _saveToMyDrive(f);
                        break;
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'open', child: Text('Open')),
                    PopupMenuItem(
                        value: 'drive', child: Text('Save to my Drive')),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  IconData _iconFor(String? mimeType) {
    if (mimeType == null) return Icons.insert_drive_file_outlined;
    if (mimeType.contains('pdf')) return Icons.picture_as_pdf_outlined;
    if (mimeType.contains('image')) return Icons.image_outlined;
    if (mimeType.contains('presentation')) return Icons.slideshow_outlined;
    if (mimeType.contains('word') || mimeType.contains('document'))
      return Icons.description_outlined;
    return Icons.insert_drive_file_outlined;
  }

  String _formatSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
    return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
  }
}

/// What the upload-details form (File Name + File Share Options) collects
/// before the actual upload to Drive happens.
class _UploadDetails {
  final String fileName;
  final MaterialVisibility visibility;
  const _UploadDetails({required this.fileName, required this.visibility});
}
