/// LOCAL ONLY — actual API key values live here so the app works with a
/// plain `flutter run`, no --dart-define flags required.
///
/// This file must be listed in .gitignore so it never gets pushed to
/// GitHub. If you ever fork/clone this project fresh, recreate this file
/// with your own keys before running.
class EnvKeys {
  static const groqApiKey =
      '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';
  static const huggingFaceApiKey = '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';
  static const openRouterApiKey =
      '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';

  /// The ID of the ONE shared Google Drive folder used by Study
  /// Materials (faculty uploads, student shares, event brochures).
  /// This folder is NOT created by the app — you create it yourself and
  /// paste its ID here. See the setup steps for how to get this.
  static const studyMaterialsFolderId = '1SANIaFD0Omt9ogoy-27FZ3cRqkm9x304';
}
